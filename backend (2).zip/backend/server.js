require("dotenv").config();

const express = require("express");
const cors = require("cors");

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Database
const db = require("./database");

// Import all routes
const authRoutes = require("./routes/authRoutes");
const profileRoutes = require("./routes/profileRoutes");
const tripRoutes = require("./routes/tripRoutes");
const travelRoutes = require("./routes/travelRoutes");
const hotelRoutes = require("./routes/hotelRoutes");
const destinationRoutes = require("./routes/destinationRoutes");
const budgetRoutes = require("./routes/budgetRoutes");
const wishlistRoutes = require("./routes/wishlistRoutes");
const reviewRoutes = require("./routes/reviewRoutes");
const notificationRoutes = require("./routes/notificationRoutes");

// Register API routes
app.use("/api/auth", authRoutes);
app.use("/api/profile", profileRoutes);
app.use("/api/trips", tripRoutes);
app.use("/api/travel", travelRoutes);
app.use("/api/hotels", hotelRoutes);
app.use("/api/destinations", destinationRoutes);
app.use("/api/budget", budgetRoutes);
app.use("/api/wishlist", wishlistRoutes);
app.use("/api/reviews", reviewRoutes);
app.use("/api/notifications", notificationRoutes);

// Home route
app.get("/", (req, res) => {
    res.json({
        success: true,
        message: "Welcome to TRIPNEST API",
        modules: [
            "Authentication",
            "Profile",
            "Trips",
            "Travel",
            "Hotels",
            "Destinations",
            "Budget",
            "Wishlist",
            "Reviews",
            "Notifications"
        ]
    });
});

// Health route
app.get("/api/health", (req, res) => {
    res.json({
        success: true,
        message: "TripNest backend is running"
    });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: `Route not found: ${req.method} ${req.originalUrl}`
    });
});

// Error handler
app.use((err, req, res, next) => {
    console.error("Server Error:", err);

    res.status(500).json({
        success: false,
        message: "Internal server error"
    });
});

// Start server
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log("================================");
    console.log("      TRIPNEST BACKEND");
    console.log("================================");
    console.log(`Server: http://localhost:${PORT}`);
    console.log("All 10 API modules registered!");
    console.log("================================");
});