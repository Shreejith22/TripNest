const Database = require("better-sqlite3");
const path = require("path");

const db = new Database(path.join(__dirname, "tripnest.db"));

db.pragma("foreign_keys = ON");

// 1. USERS TABLE
db.exec(`
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    city TEXT DEFAULT '',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
`);

// Safe migration for existing databases
const userColumns = db.pragma("table_info(users)");
const hasCityColumn = userColumns.some(
    column => column.name === "city"
);

if (!hasCityColumn) {
    db.exec("ALTER TABLE users ADD COLUMN city TEXT DEFAULT ''");
}

// 2. TRIPS TABLE
db.exec(`
CREATE TABLE IF NOT EXISTS trips (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    destination TEXT NOT NULL,
    days INTEGER NOT NULL,
    people INTEGER NOT NULL,
    travel_style TEXT DEFAULT 'Balanced',
    budget REAL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
`);

// 3. TRAVEL DETAILS TABLE
db.exec(`
CREATE TABLE IF NOT EXISTS travel_details (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    trip_id INTEGER,
    transport_type TEXT,
    departure_location TEXT,
    arrival_location TEXT,
    travel_date TEXT,
    estimated_cost REAL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (trip_id) REFERENCES trips(id)
);
`);

// 4. HOTELS TABLE
db.exec(`
CREATE TABLE IF NOT EXISTS hotels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    destination TEXT NOT NULL,
    hotel_name TEXT NOT NULL,
    location TEXT,
    price_per_night REAL DEFAULT 0,
    rating REAL DEFAULT 0,
    description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
`);

// 5. DESTINATIONS TABLE
db.exec(`
CREATE TABLE IF NOT EXISTS destinations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    city TEXT,
    state TEXT,
    country TEXT DEFAULT 'India',
    description TEXT,
    category TEXT,
    estimated_cost REAL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
`);

// 6. BUDGET TABLE
db.exec(`
CREATE TABLE IF NOT EXISTS budgets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    trip_id INTEGER,
    total_budget REAL DEFAULT 0,
    transport_cost REAL DEFAULT 0,
    hotel_cost REAL DEFAULT 0,
    food_cost REAL DEFAULT 0,
    activity_cost REAL DEFAULT 0,
    other_cost REAL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (trip_id) REFERENCES trips(id)
);
`);

// 7. WISHLIST TABLE
db.exec(`
CREATE TABLE IF NOT EXISTS wishlist (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    destination_id INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (destination_id) REFERENCES destinations(id),
    UNIQUE(user_id, destination_id)
);
`);

// 8. REVIEWS TABLE
db.exec(`
CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    destination_id INTEGER NOT NULL,
    rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
    comment TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (destination_id) REFERENCES destinations(id)
);
`);

// 9. NOTIFICATIONS TABLE
db.exec(`
CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    type TEXT DEFAULT 'general',
    is_read INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
`);

console.log("TripNest SQLite database connected successfully!");

module.exports = db;