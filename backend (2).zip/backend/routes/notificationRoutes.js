const express = require("express");
const router = express.Router();
const db = require("../database");
const jwt = require("jsonwebtoken");

// Authentication middleware
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(" ")[1];

    if (!token) {
        return res.status(401).json({
            success: false,
            message: "Please login first."
        });
    }

    try {
        req.user = jwt.verify(
            token,
            process.env.JWT_SECRET || "tripnest_dev_secret_123"
        );
        next();
    } catch (error) {
        return res.status(403).json({
            success: false,
            message: "Invalid or expired token."
        });
    }
};

// GET ALL NOTIFICATIONS
router.get("/", authenticateToken, (req, res) => {
    try {
        const notifications = db.prepare(`
            SELECT * FROM notifications
            WHERE user_id = ?
            ORDER BY created_at DESC
        `).all(req.user.id);

        res.json({
            success: true,
            notifications
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Unable to fetch notifications."
        });
    }
});

// CREATE NOTIFICATION
router.post("/", authenticateToken, (req, res) => {
    const { title, message, type } = req.body;

    if (
        !title || !title.trim() ||
        !message || !message.trim()
    ) {
        return res.status(400).json({
            success: false,
            message: "Title and message are required."
        });
    }

    try {
        const result = db.prepare(`
            INSERT INTO notifications
            (user_id, title, message, type)
            VALUES (?, ?, ?, ?)
        `).run(
            req.user.id,
            title.trim(),
            message.trim(),
            type || "general"
        );

        res.status(201).json({
            success: true,
            message: "Notification created successfully!",
            notification_id: result.lastInsertRowid
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Unable to create notification."
        });
    }
});

// MARK NOTIFICATION AS READ
router.put("/:id/read", authenticateToken, (req, res) => {
    const notificationId = Number(req.params.id);

    if (!Number.isInteger(notificationId) || notificationId < 1) {
        return res.status(400).json({
            success: false,
            message: "Invalid notification ID."
        });
    }

    try {
        const result = db.prepare(`
            UPDATE notifications
            SET is_read = 1
            WHERE id = ? AND user_id = ?
        `).run(notificationId, req.user.id);

        if (result.changes === 0) {
            return res.status(404).json({
                success: false,
                message: "Notification not found."
            });
        }

        res.json({
            success: true,
            message: "Notification marked as read."
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Unable to update notification."
        });
    }
});

// MARK ALL NOTIFICATIONS AS READ
router.put("/read-all", authenticateToken, (req, res) => {
    try {
        db.prepare(`
            UPDATE notifications
            SET is_read = 1
            WHERE user_id = ?
        `).run(req.user.id);

        res.json({
            success: true,
            message: "All notifications marked as read."
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Unable to update notifications."
        });
    }
});

// DELETE NOTIFICATION
router.delete("/:id", authenticateToken, (req, res) => {
    const notificationId = Number(req.params.id);

    if (!Number.isInteger(notificationId) || notificationId < 1) {
        return res.status(400).json({
            success: false,
            message: "Invalid notification ID."
        });
    }

    try {
        const result = db.prepare(`
            DELETE FROM notifications
            WHERE id = ? AND user_id = ?
        `).run(notificationId, req.user.id);

        if (result.changes === 0) {
            return res.status(404).json({
                success: false,
                message: "Notification not found."
            });
        }

        res.json({
            success: true,
            message: "Notification deleted successfully."
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Unable to delete notification."
        });
    }
});

module.exports = router;