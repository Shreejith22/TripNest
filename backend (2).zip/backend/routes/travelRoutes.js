const express = require("express");
const router = express.Router();

// Sample transport data
const transportOptions = [
    {
        id: 1,
        type: "Bus",
        operator: "VRL Travels",
        from: "Bangalore",
        destination: "Goa",
        estimatedPrice: 1200,
        duration: "12 hours"
    },
    {
        id: 2,
        type: "Train",
        operator: "Indian Railways",
        from: "Bangalore",
        destination: "Mysore",
        estimatedPrice: 250,
        duration: "3 hours"
    },
    {
        id: 3,
        type: "Flight",
        operator: "IndiGo",
        from: "Bangalore",
        destination: "Jaipur",
        estimatedPrice: 5500,
        duration: "2.5 hours"
    },
    {
        id: 4,
        type: "Bus",
        operator: "KSRTC",
        from: "Bangalore",
        destination: "Ooty",
        estimatedPrice: 800,
        duration: "8 hours"
    },
    {
        id: 5,
        type: "Train",
        operator: "Indian Railways",
        from: "Bangalore",
        destination: "Goa",
        estimatedPrice: 600,
        duration: "14 hours"
    }
];

// GET ALL TRANSPORT OPTIONS
router.get("/", (req, res) => {
    res.json({
        success: true,
        count: transportOptions.length,
        transportOptions
    });
});

// SEARCH TRANSPORT
router.get("/search", (req, res) => {
    const destination = String(req.query.destination || "").trim();
    const from = String(req.query.from || "").trim();
    const type = String(req.query.type || "").trim();

    let results = [...transportOptions];

    if (destination) {
        results = results.filter(option =>
            option.destination.toLowerCase().includes(destination.toLowerCase())
        );
    }

    if (from) {
        results = results.filter(option =>
            option.from.toLowerCase().includes(from.toLowerCase())
        );
    }

    if (type) {
        results = results.filter(option =>
            option.type.toLowerCase() === type.toLowerCase()
        );
    }

    res.json({
        success: true,
        count: results.length,
        transportOptions: results
    });
});

// FILTER BY TRANSPORT TYPE
router.get("/type/:type", (req, res) => {
    const type = req.params.type.toLowerCase();

    const results = transportOptions.filter(option =>
        option.type.toLowerCase() === type
    );

    res.json({
        success: true,
        count: results.length,
        transportOptions: results
    });
});

// GET TRANSPORT DETAILS
router.get("/:id", (req, res) => {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({
            success: false,
            message: "Invalid transport ID."
        });
    }

    const option = transportOptions.find(item => item.id === id);

    if (!option) {
        return res.status(404).json({
            success: false,
            message: "Transport option not found."
        });
    }

    res.json({
        success: true,
        transport: option
    });
});

module.exports = router;