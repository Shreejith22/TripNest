const express = require("express");
const router = express.Router();
const db = require("../database");
const jwt = require("jsonwebtoken");

// Authentication middleware
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(" ")[1];

    if (!token) {
        return res.status(401).json({
            success: false,
            message: "Please login first."
        });
    }

    try {
        req.user = jwt.verify(
            token,
            process.env.JWT_SECRET || "tripnest_dev_secret_123"
        );
        next();
    } catch (error) {
        return res.status(403).json({
            success: false,
            message: "Invalid or expired token."
        });
    }
};

// GET REVIEWS FOR A DESTINATION
router.get("/destination/:destinationId", (req, res) => {
    const destinationId = Number(req.params.destinationId);

    if (!Number.isInteger(destinationId) || destinationId < 1) {
        return res.status(400).json({
            success: false,
            message: "Invalid destination ID."
        });
    }

    try {
        const reviews = db.prepare(`
            SELECT r.id, r.destination_id, r.rating,
                   r.comment, r.created_at, u.name AS user_name
            FROM reviews r
            JOIN users u ON r.user_id = u.id
            WHERE r.destination_id = ?
            ORDER BY r.created_at DESC
        `).all(destinationId);

        res.json({
            success: true,
            reviews
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Unable to fetch reviews."
        });
    }
});

// ADD REVIEW
router.post("/", authenticateToken, (req, res) => {
    const { destination_id, rating, comment } = req.body;

    if (
        !Number.isInteger(Number(destination_id)) ||
        Number(destination_id) < 1 ||
        !Number.isInteger(Number(rating)) ||
        Number(rating) < 1 ||
        Number(rating) > 5 ||
        !comment ||
        !comment.trim()
    ) {
        return res.status(400).json({
            success: false,
            message: "Provide a valid destination, rating (1-5), and comment."
        });
    }

    try {
        const destination = db.prepare(
            "SELECT id FROM destinations WHERE id = ?"
        ).get(Number(destination_id));

        if (!destination) {
            return res.status(404).json({
                success: false,
                message: "Destination not found."
            });
        }

        const result = db.prepare(`
            INSERT INTO reviews
            (user_id, destination_id, rating, comment)
            VALUES (?, ?, ?, ?)
        `).run(
            req.user.id,
            Number(destination_id),
            Number(rating),
            comment.trim()
        );

        res.status(201).json({
            success: true,
            message: "Review submitted successfully!",
            review_id: result.lastInsertRowid
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Unable to submit review."
        });
    }
});

// UPDATE OWN REVIEW
router.put("/:id", authenticateToken, (req, res) => {
    const reviewId = Number(req.params.id);
    const { rating, comment } = req.body;

    if (
        !Number.isInteger(reviewId) ||
        reviewId < 1 ||
        !Number.isInteger(Number(rating)) ||
        Number(rating) < 1 ||
        Number(rating) > 5 ||
        !comment ||
        !comment.trim()
    ) {
        return res.status(400).json({
            success: false,
            message: "Provide a valid review ID, rating, and comment."
        });
    }

    try {
        const result = db.prepare(`
            UPDATE reviews
            SET rating = ?, comment = ?
            WHERE id = ? AND user_id = ?
        `).run(
            Number(rating),
            comment.trim(),
            reviewId,
            req.user.id
        );

        if (result.changes === 0) {
            return res.status(404).json({
                success: false,
                message: "Review not found."
            });
        }

        res.json({
            success: true,
            message: "Review updated successfully!"
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Unable to update review."
        });
    }
});

// DELETE OWN REVIEW
router.delete("/:id", authenticateToken, (req, res) => {
    const reviewId = Number(req.params.id);

    if (!Number.isInteger(reviewId) || reviewId < 1) {
        return res.status(400).json({
            success: false,
            message: "Invalid review ID."
        });
    }

    try {
        const result = db.prepare(`
            DELETE FROM reviews
            WHERE id = ? AND user_id = ?
        `).run(reviewId, req.user.id);

        if (result.changes === 0) {
            return res.status(404).json({
                success: false,
                message: "Review not found."
            });
        }

        res.json({
            success: true,
            message: "Review deleted successfully!"
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Unable to delete review."
        });
    }
});

module.exports = router;