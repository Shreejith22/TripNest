const express = require("express");
const jwt = require("jsonwebtoken");
const db = require("../database");

const router = express.Router();

const JWT_SECRET =
    process.env.JWT_SECRET ||
    "tripnest-development-secret-change-before-deployment";

// AUTHENTICATION
function verifyToken(req, res, next) {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({
            success: false,
            message: "Please login first."
        });
    }

    try {
        const token = authHeader.split(" ")[1];
        req.user = jwt.verify(token, JWT_SECRET);
        next();
    } catch (error) {
        return res.status(401).json({
            success: false,
            message: "Invalid or expired token."
        });
    }
}

// VALIDATE TRIP DETAILS
function validateTrip(data) {
    const { destination, days, people, budget } = data;

    return (
        typeof destination === "string" &&
        destination.trim().length > 0 &&
        destination.trim().length <= 150 &&
        Number.isInteger(Number(days)) &&
        Number(days) >= 1 &&
        Number(days) <= 365 &&
        Number.isInteger(Number(people)) &&
        Number(people) >= 1 &&
        Number(people) <= 100 &&
        (budget === undefined ||
            (Number.isFinite(Number(budget)) && Number(budget) >= 0))
    );
}

// CREATE TRIP
router.post("/", verifyToken, (req, res) => {
    try {
        const data = req.body || {};

        if (!validateTrip(data)) {
            return res.status(400).json({
                success: false,
                message: "Please provide valid trip details."
            });
        }

        const {
            destination,
            days,
            people,
            travel_style = "Balanced",
            budget = 0
        } = data;

        const result = db.prepare(`
            INSERT INTO trips
            (user_id, destination, days, people, travel_style, budget)
            VALUES (?, ?, ?, ?, ?, ?)
        `).run(
            req.user.id,
            destination.trim(),
            Number(days),
            Number(people),
            typeof travel_style === "string"
                ? travel_style.trim()
                : "Balanced",
            Number(budget)
        );

        const trip = db.prepare(
            "SELECT * FROM trips WHERE id = ?"
        ).get(result.lastInsertRowid);

        return res.status(201).json({
            success: true,
            message: "Trip created successfully!",
            trip
        });

    } catch (error) {
        console.error("Create trip error:", error);

        return res.status(500).json({
            success: false,
            message: "Could not create trip."
        });
    }
});

// GET ALL USER TRIPS
router.get("/", verifyToken, (req, res) => {
    try {
        const trips = db.prepare(`
            SELECT * FROM trips
            WHERE user_id = ?
            ORDER BY created_at DESC
        `).all(req.user.id);

        return res.json({
            success: true,
            trips
        });

    } catch (error) {
        console.error("Fetch trips error:", error);

        return res.status(500).json({
            success: false,
            message: "Could not fetch trips."
        });
    }
});

// GET SINGLE TRIP
router.get("/:id", verifyToken, (req, res) => {
    try {
        const trip = db.prepare(`
            SELECT * FROM trips
            WHERE id = ? AND user_id = ?
        `).get(req.params.id, req.user.id);

        if (!trip) {
            return res.status(404).json({
                success: false,
                message: "Trip not found."
            });
        }

        return res.json({
            success: true,
            trip
        });

    } catch (error) {
        console.error("Fetch trip error:", error);

        return res.status(500).json({
            success: false,
            message: "Could not fetch trip."
        });
    }
});

// UPDATE TRIP
router.put("/:id", verifyToken, (req, res) => {
    try {
        const data = req.body || {};

        if (!validateTrip(data)) {
            return res.status(400).json({
                success: false,
                message: "Please provide valid trip details."
            });
        }

        const {
            destination,
            days,
            people,
            travel_style = "Balanced",
            budget = 0
        } = data;

        const result = db.prepare(`
            UPDATE trips
            SET destination = ?,
                days = ?,
                people = ?,
                travel_style = ?,
                budget = ?
            WHERE id = ? AND user_id = ?
        `).run(
            destination.trim(),
            Number(days),
            Number(people),
            typeof travel_style === "string"
                ? travel_style.trim()
                : "Balanced",
            Number(budget),
            req.params.id,
            req.user.id
        );

        if (result.changes === 0) {
            return res.status(404).json({
                success: false,
                message: "Trip not found."
            });
        }

        const trip = db.prepare(
            "SELECT * FROM trips WHERE id = ? AND user_id = ?"
        ).get(req.params.id, req.user.id);

        return res.json({
            success: true,
            message: "Trip updated successfully!",
            trip
        });

    } catch (error) {
        console.error("Update trip error:", error);

        return res.status(500).json({
            success: false,
            message: "Could not update trip."
        });
    }
});

// DELETE TRIP
router.delete("/:id", verifyToken, (req, res) => {
    try {
        const result = db.prepare(`
            DELETE FROM trips
            WHERE id = ? AND user_id = ?
        `).run(req.params.id, req.user.id);

        if (result.changes === 0) {
            return res.status(404).json({
                success: false,
                message: "Trip not found."
            });
        }

        return res.json({
            success: true,
            message: "Trip deleted successfully!"
        });

    } catch (error) {
        console.error("Delete trip error:", error);

        return res.status(500).json({
            success: false,
            message: "Could not delete trip."
        });
    }
});

module.exports = router;