const express = require("express");
const jwt = require("jsonwebtoken");

const router = express.Router();

const JWT_SECRET = process.env.JWT_SECRET || "tripnest_dev_secret_123";

// Authentication middleware
function verifyToken(req, res, next) {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({
            success: false,
            message: "Authorization token required"
        });
    }

    try {
        const token = authHeader.split(" ")[1];
        req.user = jwt.verify(token, JWT_SECRET);
        next();
    } catch (error) {
        return res.status(401).json({
            success: false,
            message: "Invalid or expired token"
        });
    }
}

// CALCULATE TRIP BUDGET
router.post("/calculate", verifyToken, (req, res) => {
    try {
        const {
            travelCost,
            hotelCost,
            foodCost,
            activitiesCost,
            otherCost,
            people,
            days
        } = req.body;

        const values = [
            travelCost,
            hotelCost,
            foodCost,
            activitiesCost,
            otherCost
        ];

        if (!Number.isInteger(people) || people < 1 ||
            !Number.isInteger(days) || days < 1) {
            return res.status(400).json({
                success: false,
                message: "People and days must be positive whole numbers"
            });
        }

        if (values.some(value =>
            value === undefined ||
            typeof value !== "number" ||
            !Number.isFinite(value) ||
            value < 0
        )) {
            return res.status(400).json({
                success: false,
                message: "All expense values must be valid non-negative numbers"
            });
        }

        const totalBudget = values.reduce(
            (total, cost) => total + cost, 0
        );

        const perPerson = totalBudget / people;
        const perDay = totalBudget / days;

        res.json({
            success: true,
            budget: {
                travelCost,
                hotelCost,
                foodCost,
                activitiesCost,
                otherCost,
                totalBudget,
                people,
                days,
                perPerson,
                perDay
            }
        });

    } catch (error) {
        console.error("Budget calculation error:", error);

        res.status(500).json({
            success: false,
            message: "Budget calculation failed"
        });
    }
});

module.exports = router;