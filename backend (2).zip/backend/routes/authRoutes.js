const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../database");

const router = express.Router();

const JWT_SECRET =
    process.env.JWT_SECRET || "tripnest-development-secret-change-before-deployment";

// Generate token
function generateToken(user) {
    return jwt.sign(
        { id: user.id, email: user.email },
        JWT_SECRET,
        { expiresIn: "7d" }
    );
}

// Authentication middleware
function authenticateToken(req, res, next) {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({
            message: "Access denied. Please login."
        });
    }

    try {
        const token = authHeader.split(" ")[1];
        req.user = jwt.verify(token, JWT_SECRET);
        next();
    } catch (error) {
        return res.status(401).json({
            message: "Invalid or expired token."
        });
    }
}

// REGISTER
router.post("/register", async (req, res) => {
    try {
        const { name, email, password, city = "" } = req.body || {};

        if (
            typeof name !== "string" ||
            typeof email !== "string" ||
            typeof password !== "string"
        ) {
            return res.status(400).json({
                message: "Name, email and password are required."
            });
        }

        const cleanName = name.trim();
        const cleanEmail = email.trim().toLowerCase();
        const cleanCity = typeof city === "string" ? city.trim() : "";

        if (!cleanName || !cleanEmail || !password) {
            return res.status(400).json({
                message: "Please enter all required details."
            });
        }

        if (cleanName.length > 100 || cleanEmail.length > 254) {
            return res.status(400).json({
                message: "Name or email is too long."
            });
        }

        if (password.length < 6 || password.length > 72) {
            return res.status(400).json({
                message: "Password must contain 6 to 72 characters."
            });
        }

        const existingUser = db.prepare(
            "SELECT id FROM users WHERE email = ?"
        ).get(cleanEmail);

        if (existingUser) {
            return res.status(409).json({
                message: "Email already registered. Please login."
            });
        }

        const hashedPassword = await bcrypt.hash(password, 12);

        const result = db.prepare(`
            INSERT INTO users (name, email, password, city)
            VALUES (?, ?, ?, ?)
        `).run(cleanName, cleanEmail, hashedPassword, cleanCity);

        const user = db.prepare(`
            SELECT id, name, email, city, created_at
            FROM users WHERE id = ?
        `).get(result.lastInsertRowid);

        return res.status(201).json({
            message: "Account created successfully!",
            token: generateToken(user),
            user
        });

    } catch (error) {
        console.error("Registration error:", error);

        return res.status(500).json({
            message: "Server error during registration."
        });
    }
});

// LOGIN
router.post("/login", async (req, res) => {
    try {
        const { email, password } = req.body || {};

        if (
            typeof email !== "string" ||
            typeof password !== "string" ||
            !email.trim() ||
            !password
        ) {
            return res.status(400).json({
                message: "Email and password are required."
            });
        }

        const cleanEmail = email.trim().toLowerCase();

        const user = db.prepare(
            "SELECT * FROM users WHERE email = ?"
        ).get(cleanEmail);

        if (!user) {
            return res.status(401).json({
                message: "Invalid email or password."
            });
        }

        const passwordMatch = await bcrypt.compare(
            password,
            user.password
        );

        if (!passwordMatch) {
            return res.status(401).json({
                message: "Invalid email or password."
            });
        }

        const safeUser = {
            id: user.id,
            name: user.name,
            email: user.email,
            city: user.city || "",
            created_at: user.created_at
        };

        return res.status(200).json({
            message: "Login successful!",
            token: generateToken(user),
            user: safeUser
        });

    } catch (error) {
        console.error("Login error:", error);

        return res.status(500).json({
            message: "Server error during login."
        });
    }
});

// PROFILE
router.get("/profile", authenticateToken, (req, res) => {
    try {
        const user = db.prepare(`
            SELECT id, name, email, city, created_at
            FROM users WHERE id = ?
        `).get(req.user.id);

        if (!user) {
            return res.status(404).json({
                message: "User not found."
            });
        }

        return res.status(200).json({
            message: "Profile fetched successfully.",
            user
        });

    } catch (error) {
        console.error("Profile error:", error);

        return res.status(500).json({
            message: "Could not fetch profile."
        });
    }
});

module.exports = router;