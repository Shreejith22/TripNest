const express = require("express");
const router = express.Router();
const db = require("../database");
const jwt = require("jsonwebtoken");

// Authentication middleware
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(" ")[1];

    if (!token) {
        return res.status(401).json({
            success: false,
            message: "Please login first."
        });
    }

    try {
        req.user = jwt.verify(
            token,
            process.env.JWT_SECRET || "tripnest_dev_secret_123"
        );
        next();
    } catch (error) {
        return res.status(403).json({
            success: false,
            message: "Invalid or expired token."
        });
    }
};

// GET USER WISHLIST
router.get("/", authenticateToken, (req, res) => {
    try {
        const wishlist = db.prepare(`
            SELECT w.id, w.destination_id, w.created_at,
                   d.name, d.city, d.state, d.country,
                   d.description, d.category, d.estimated_cost
            FROM wishlist w
            JOIN destinations d ON w.destination_id = d.id
            WHERE w.user_id = ?
            ORDER BY w.created_at DESC
        `).all(req.user.id);

        res.json({
            success: true,
            wishlist
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Unable to fetch wishlist."
        });
    }
});

// ADD DESTINATION TO WISHLIST
router.post("/", authenticateToken, (req, res) => {
    const { destination_id } = req.body;

    if (!Number.isInteger(Number(destination_id)) ||
        Number(destination_id) < 1) {
        return res.status(400).json({
            success: false,
            message: "Valid destination ID is required."
        });
    }

    try {
        const destination = db.prepare(
            "SELECT id FROM destinations WHERE id = ?"
        ).get(Number(destination_id));

        if (!destination) {
            return res.status(404).json({
                success: false,
                message: "Destination not found."
            });
        }

        const existing = db.prepare(`
            SELECT id FROM wishlist
            WHERE user_id = ? AND destination_id = ?
        `).get(req.user.id, Number(destination_id));

        if (existing) {
            return res.status(409).json({
                success: false,
                message: "Destination already in wishlist."
            });
        }

        db.prepare(`
            INSERT INTO wishlist (user_id, destination_id)
            VALUES (?, ?)
        `).run(req.user.id, Number(destination_id));

        res.status(201).json({
            success: true,
            message: "Destination added to wishlist!"
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Unable to add destination."
        });
    }
});

// REMOVE DESTINATION FROM WISHLIST
router.delete("/:id", authenticateToken, (req, res) => {
    const wishlistId = Number(req.params.id);

    if (!Number.isInteger(wishlistId) || wishlistId < 1) {
        return res.status(400).json({
            success: false,
            message: "Invalid wishlist ID."
        });
    }

    try {
        const result = db.prepare(`
            DELETE FROM wishlist
            WHERE id = ? AND user_id = ?
        `).run(wishlistId, req.user.id);

        if (result.changes === 0) {
            return res.status(404).json({
                success: false,
                message: "Wishlist item not found."
            });
        }

        res.json({
            success: true,
            message: "Destination removed from wishlist."
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Unable to remove destination."
        });
    }
});

module.exports = router;