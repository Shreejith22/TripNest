const express = require("express");
const router = express.Router();

// Sample hotel data
const hotels = [
    {
        id: 1,
        name: "Mountain View Resort",
        destination: "Manali",
        pricePerNight: 2500,
        rating: 4.5,
        category: "Resort",
        description: "Beautiful mountain views and comfortable rooms."
    },
    {
        id: 2,
        name: "Sea Breeze Hotel",
        destination: "Goa",
        pricePerNight: 3000,
        rating: 4.3,
        category: "Hotel",
        description: "Enjoy a relaxing stay near the beach."
    },
    {
        id: 3,
        name: "Royal Heritage Stay",
        destination: "Mysore",
        pricePerNight: 1800,
        rating: 4.4,
        category: "Hotel",
        description: "Comfortable accommodation near heritage attractions."
    },
    {
        id: 4,
        name: "Green Valley Resort",
        destination: "Ooty",
        pricePerNight: 2200,
        rating: 4.6,
        category: "Resort",
        description: "A peaceful stay surrounded by green hills."
    },
    {
        id: 5,
        name: "Pink City Residency",
        destination: "Jaipur",
        pricePerNight: 2000,
        rating: 4.2,
        category: "Hotel",
        description: "Explore Jaipur with a comfortable city stay."
    }
];

// GET ALL HOTELS
router.get("/", (req, res) => {
    res.json({
        success: true,
        count: hotels.length,
        hotels
    });
});

// SEARCH AND FILTER HOTELS
router.get("/search", (req, res) => {
    const destination = String(req.query.destination || "").trim();
    const category = String(req.query.category || "").trim();

    const maxPrice = req.query.maxPrice !== undefined
        ? Number(req.query.maxPrice)
        : Infinity;

    const minRating = req.query.minRating !== undefined
        ? Number(req.query.minRating)
        : 0;

    if (
        maxPrice < 0 ||
        !Number.isFinite(maxPrice) && maxPrice !== Infinity ||
        !Number.isFinite(minRating) ||
        minRating < 0 ||
        minRating > 5
    ) {
        return res.status(400).json({
            success: false,
            message: "Invalid hotel filter values."
        });
    }

    const results = hotels.filter(hotel => {
        return (
            hotel.destination.toLowerCase().includes(destination.toLowerCase()) &&
            hotel.category.toLowerCase().includes(category.toLowerCase()) &&
            hotel.pricePerNight <= maxPrice &&
            hotel.rating >= minRating
        );
    });

    res.json({
        success: true,
        count: results.length,
        hotels: results
    });
});

// FILTER HOTELS BY PRICE
router.get("/price", (req, res) => {
    const maxPrice = Number(req.query.max);

    if (
        req.query.max === undefined ||
        !Number.isFinite(maxPrice) ||
        maxPrice < 0
    ) {
        return res.status(400).json({
            success: false,
            message: "Please provide a valid maximum price."
        });
    }

    const results = hotels.filter(
        hotel => hotel.pricePerNight <= maxPrice
    );

    res.json({
        success: true,
        count: results.length,
        hotels: results
    });
});

// GET HOTEL DETAILS
router.get("/:id", (req, res) => {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({
            success: false,
            message: "Invalid hotel ID."
        });
    }

    const hotel = hotels.find(item => item.id === id);

    if (!hotel) {
        return res.status(404).json({
            success: false,
            message: "Hotel not found."
        });
    }

    res.json({
        success: true,
        hotel
    });
});

module.exports = router;