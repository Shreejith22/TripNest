const express = require("express");

const router = express.Router();

// Destination data
const destinations = [
    {
        id: 1,
        name: "Manali",
        state: "Himachal Pradesh",
        country: "India",
        category: "Mountain",
        description: "Explore beautiful mountains, valleys and snow-covered landscapes.",
        estimatedBudget: 12000
    },
    {
        id: 2,
        name: "Goa",
        state: "Goa",
        country: "India",
        category: "Beach",
        description: "Enjoy beautiful beaches, sunsets and coastal experiences.",
        estimatedBudget: 10000
    },
    {
        id: 3,
        name: "Mysore",
        state: "Karnataka",
        country: "India",
        category: "Heritage",
        description: "Discover palaces, gardens and rich cultural heritage.",
        estimatedBudget: 5000
    },
    {
        id: 4,
        name: "Ooty",
        state: "Tamil Nadu",
        country: "India",
        category: "Hill Station",
        description: "Experience green hills, tea gardens and pleasant weather.",
        estimatedBudget: 7000
    },
    {
        id: 5,
        name: "Jaipur",
        state: "Rajasthan",
        country: "India",
        category: "Heritage",
        description: "Explore forts, palaces and colourful markets.",
        estimatedBudget: 8000
    },
    {
        id: 6,
        name: "Kerala",
        state: "Kerala",
        country: "India",
        category: "Nature",
        description: "Discover backwaters, greenery and beautiful landscapes.",
        estimatedBudget: 9000
    }
];

// GET ALL DESTINATIONS
router.get("/", (req, res) => {
    res.json({
        success: true,
        count: destinations.length,
        destinations
    });
});

// SEARCH DESTINATIONS
router.get("/search", (req, res) => {
    const search = (req.query.q || "").toLowerCase();

    const results = destinations.filter(destination =>
        destination.name.toLowerCase().includes(search) ||
        destination.state.toLowerCase().includes(search) ||
        destination.category.toLowerCase().includes(search)
    );

    res.json({
        success: true,
        count: results.length,
        destinations: results
    });
});

// FILTER BY CATEGORY
router.get("/category/:category", (req, res) => {
    const category = req.params.category.toLowerCase();

    const results = destinations.filter(destination =>
        destination.category.toLowerCase() === category
    );

    res.json({
        success: true,
        count: results.length,
        destinations: results
    });
});

// GET DESTINATION DETAILS
router.get("/:id", (req, res) => {
    const destination = destinations.find(
        item => item.id === Number(req.params.id)
    );

    if (!destination) {
        return res.status(404).json({
            success: false,
            message: "Destination not found"
        });
    }

    res.json({
        success: true,
        destination
    });
});

module.exports = router;