const express = require("express");
const jwt = require("jsonwebtoken");
const db = require("../database");

const router = express.Router();

const JWT_SECRET =
    process.env.JWT_SECRET ||
    "tripnest-development-secret-change-before-deployment";

// Authentication middleware
function authenticateToken(req, res, next) {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({
            success: false,
            message: "Access denied. Please login."
        });
    }

    try {
        const token = authHeader.split(" ")[1];
        req.user = jwt.verify(token, JWT_SECRET);
        next();
    } catch (error) {
        return res.status(401).json({
            success: false,
            message: "Invalid or expired token."
        });
    }
}

// GET USER PROFILE
router.get("/", authenticateToken, (req, res) => {
    try {
        const user = db.prepare(`
            SELECT id, name, email, city, created_at
            FROM users
            WHERE id = ?
        `).get(req.user.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found."
            });
        }

        return res.json({
            success: true,
            user
        });

    } catch (error) {
        console.error("Profile fetch error:", error);

        return res.status(500).json({
            success: false,
            message: "Database error."
        });
    }
});

// UPDATE USER PROFILE
router.put("/", authenticateToken, (req, res) => {
    try {
        const { name, city } = req.body || {};

        if (typeof name !== "string" || !name.trim()) {
            return res.status(400).json({
                success: false,
                message: "Name is required."
            });
        }

        if (name.trim().length > 100) {
            return res.status(400).json({
                success: false,
                message: "Name must be 100 characters or fewer."
            });
        }

        const cleanCity =
            typeof city === "string" ? city.trim() : "";

        db.prepare(`
            UPDATE users
            SET name = ?, city = ?
            WHERE id = ?
        `).run(name.trim(), cleanCity, req.user.id);

        const user = db.prepare(`
            SELECT id, name, email, city, created_at
            FROM users
            WHERE id = ?
        `).get(req.user.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found."
            });
        }

        return res.json({
            success: true,
            message: "Profile updated successfully.",
            user
        });

    } catch (error) {
        console.error("Profile update error:", error);

        return res.status(500).json({
            success: false,
            message: "Unable to update profile."
        });
    }
});

module.exports = router;